# TransitOps — Smart Transport Operations Platform

A full-stack fleet operations platform: vehicle & driver management, trip
dispatch with automatic business-rule enforcement, maintenance workflow,
fuel/expense tracking, KPI dashboard, and analytics/reports.

**Stack:** React + Vite (frontend) · Node.js + Express + sql.js/SQLite (backend) · JWT auth + RBAC

## 1. Run the backend

```bash
cd backend
npm install
npm start
```

This starts the API on `http://localhost:4000` and creates `transitops.sqlite`
on first run, seeded with demo data (4 vehicles, 4 drivers, 4 users — one per role).

## 2. Run the frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. The Vite dev server proxies `/api/*` to the
backend on port 4000 (see `frontend/vite.config.js`), so both must be running.

## 3. Demo logins (password for all: `Password@123`)

| Role               | Email                          |
|---------------------|---------------------------------|
| Fleet Manager        | fleetmanager@transitops.com    |
| Driver / Dispatcher  | dispatcher@transitops.com      |
| Safety Officer       | safety@transitops.com          |
| Financial Analyst    | finance@transitops.com         |

## Business rules implemented (server-side, not just UI)

- Vehicle registration number is unique.
- Retired / In Shop vehicles never appear in the dispatch pool.
- Drivers with expired licenses or Suspended status cannot be dispatched.
- A vehicle or driver already On Trip cannot be assigned to another trip.
- Cargo weight cannot exceed a vehicle's max load capacity (enforced at create *and* dispatch).
- Dispatch/Complete/Cancel automatically flips vehicle & driver status.
- Opening a maintenance record flips the vehicle to In Shop; closing it restores Available (unless Retired).
- Reports compute Fuel Efficiency, Operational Cost, and ROI = (Revenue − (Maintenance + Fuel)) / Acquisition Cost.
- CSV export available from the Reports page (Fleet Manager / Financial Analyst only).

## Project layout

```
backend/
  server.js          Express app entry
  db.js               sql.js schema, seed data, query helpers
  middleware/auth.js  JWT verification + RBAC
  routes/             auth, vehicles, drivers, trips, maintenance, fuel-logs, expenses, dashboard, reports
frontend/
  src/pages/          Login, Dashboard, Vehicles, Drivers, Trips, Maintenance, FuelExpenses, Reports
  src/components/      Layout (sidebar), StatusBadge, CapacityGauge
  src/context/         AuthContext (JWT stored in localStorage)
```

## Notes / next steps if you extend this

- PDF export, email reminders for expiring licenses, and vehicle document
  uploads (spec's bonus features) are not yet built.
- Passwords use bcrypt; JWT secret is a dev default in `middleware/auth.js` —
  set `JWT_SECRET` in a `.env` file before any real deployment.
- The DB is a single `transitops.sqlite` file next to `server.js`, written via
  sql.js so there's no native compilation step — convenient for a hackathon demo,
  but swap for `better-sqlite3` or Postgres if you need concurrent write safety.
