import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const DEMO_ACCOUNTS = [
  { label: "Fleet Manager", email: "fleetmanager@transitops.com" },
  { label: "Driver / Dispatcher", email: "dispatcher@transitops.com" },
  { label: "Safety Officer", email: "safety@transitops.com" },
  { label: "Financial Analyst", email: "finance@transitops.com" }
];

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("Password@123");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(email, password);
      navigate("/");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-mark">
          <span className="dot" />
          <h1>TransitOps</h1>
        </div>
        <p className="login-sub">Smart transport operations platform</p>

        {error && <div className="error-banner">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="you@transitops.com" />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <button className="btn-primary" type="submit" disabled={busy} style={{ width: "100%" }}>
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <div className="demo-accounts">
          Demo accounts (password: Password@123)
          <br />
          {DEMO_ACCOUNTS.map((acc) => (
            <div key={acc.email}>
              {acc.label} &mdash;{" "}
              <button type="button" onClick={() => setEmail(acc.email)}>{acc.email}</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
