import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";

export default function FuelExpenses() {
  const { user } = useAuth();
  const canLogFuel = ["FleetManager", "FinancialAnalyst", "Driver"].includes(user?.role);
  const canLogExpense = ["FleetManager", "FinancialAnalyst"].includes(user?.role);

  const [fuelLogs, setFuelLogs] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [error, setError] = useState("");
  const [fuelOpen, setFuelOpen] = useState(false);
  const [expenseOpen, setExpenseOpen] = useState(false);
  const [fuelForm, setFuelForm] = useState({ vehicle_id: "", liters: "", cost: "", log_date: "" });
  const [expenseForm, setExpenseForm] = useState({ vehicle_id: "", category: "Toll", amount: "", expense_date: "", description: "" });

  async function load() {
    try {
      const [f, e, v] = await Promise.all([api.get("/fuel-logs"), api.get("/expenses"), api.get("/vehicles")]);
      setFuelLogs(f); setExpenses(e); setVehicles(v);
    } catch (err) { setError(err.message); }
  }
  useEffect(() => { load(); }, []);

  async function submitFuel(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/fuel-logs", { ...fuelForm, vehicle_id: Number(fuelForm.vehicle_id), liters: Number(fuelForm.liters), cost: Number(fuelForm.cost) });
      setFuelOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  async function submitExpense(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/expenses", { ...expenseForm, vehicle_id: expenseForm.vehicle_id ? Number(expenseForm.vehicle_id) : null, amount: Number(expenseForm.amount) });
      setExpenseOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Fuel & Expenses</h2>
          <div className="sub">Track fuel logs and operational expenses per vehicle</div>
        </div>
      </div>

      {error && <div className="alert-banner">{error}</div>}

      <div className="panel">
        <div className="panel-header">
          <h3>Fuel Logs</h3>
          {canLogFuel && <button className="btn-secondary" onClick={() => { setFuelForm({ vehicle_id: "", liters: "", cost: "", log_date: new Date().toISOString().slice(0, 10) }); setFuelOpen(true); }}>+ Log Fuel</button>}
        </div>
        <table>
          <thead><tr><th>Vehicle</th><th>Liters</th><th>Cost</th><th>Date</th></tr></thead>
          <tbody>
            {fuelLogs.length === 0 && <tr className="empty-row"><td colSpan={4}>No fuel logs yet.</td></tr>}
            {fuelLogs.map((f) => (
              <tr key={f.id}><td>{f.registration_number}</td><td>{f.liters} L</td><td>₹{f.cost}</td><td>{f.log_date}</td></tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="panel">
        <div className="panel-header">
          <h3>Expenses</h3>
          {canLogExpense && <button className="btn-secondary" onClick={() => { setExpenseForm({ vehicle_id: "", category: "Toll", amount: "", expense_date: new Date().toISOString().slice(0, 10), description: "" }); setExpenseOpen(true); }}>+ Log Expense</button>}
        </div>
        <table>
          <thead><tr><th>Vehicle</th><th>Category</th><th>Amount</th><th>Date</th><th>Note</th></tr></thead>
          <tbody>
            {expenses.length === 0 && <tr className="empty-row"><td colSpan={5}>No expenses logged yet.</td></tr>}
            {expenses.map((ex) => (
              <tr key={ex.id}>
                <td>{vehicles.find((v) => v.id === ex.vehicle_id)?.registration_number || "—"}</td>
                <td>{ex.category}</td><td>₹{ex.amount}</td><td>{ex.expense_date}</td>
                <td style={{ fontFamily: "var(--font-body)" }}>{ex.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {fuelOpen && (
        <div className="modal-backdrop" onClick={() => setFuelOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Log Fuel</h3>
            <form onSubmit={submitFuel}>
              <div className="field">
                <label>Vehicle</label>
                <select required value={fuelForm.vehicle_id} onChange={(e) => setFuelForm({ ...fuelForm, vehicle_id: e.target.value })}>
                  <option value="">Select vehicle…</option>
                  {vehicles.map((v) => <option key={v.id} value={v.id}>{v.registration_number} &mdash; {v.name}</option>)}
                </select>
              </div>
              <div className="form-row">
                <div className="field"><label>Liters</label><input required type="number" value={fuelForm.liters} onChange={(e) => setFuelForm({ ...fuelForm, liters: e.target.value })} /></div>
                <div className="field"><label>Cost (₹)</label><input required type="number" value={fuelForm.cost} onChange={(e) => setFuelForm({ ...fuelForm, cost: e.target.value })} /></div>
              </div>
              <div className="field"><label>Date</label><input required type="date" value={fuelForm.log_date} onChange={(e) => setFuelForm({ ...fuelForm, log_date: e.target.value })} /></div>
              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setFuelOpen(false)}>Cancel</button>
                <button type="submit" className="btn-primary">Save Log</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {expenseOpen && (
        <div className="modal-backdrop" onClick={() => setExpenseOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Log Expense</h3>
            <form onSubmit={submitExpense}>
              <div className="field">
                <label>Vehicle (optional)</label>
                <select value={expenseForm.vehicle_id} onChange={(e) => setExpenseForm({ ...expenseForm, vehicle_id: e.target.value })}>
                  <option value="">General / unassigned</option>
                  {vehicles.map((v) => <option key={v.id} value={v.id}>{v.registration_number} &mdash; {v.name}</option>)}
                </select>
              </div>
              <div className="form-row">
                <div className="field">
                  <label>Category</label>
                  <select value={expenseForm.category} onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value })}>
                    <option value="Toll">Toll</option>
                    <option value="Maintenance">Maintenance</option>
                    <option value="Insurance">Insurance</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div className="field"><label>Amount (₹)</label><input required type="number" value={expenseForm.amount} onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })} /></div>
              </div>
              <div className="field"><label>Date</label><input required type="date" value={expenseForm.expense_date} onChange={(e) => setExpenseForm({ ...expenseForm, expense_date: e.target.value })} /></div>
              <div className="field"><label>Note</label><input value={expenseForm.description} onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })} /></div>
              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setExpenseOpen(false)}>Cancel</button>
                <button type="submit" className="btn-primary">Save Expense</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
