import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";
import StatusBadge from "../components/StatusBadge";

const EMPTY = { name: "", license_number: "", license_category: "LMV", license_expiry: "", contact_number: "", safety_score: 100 };

function isExpired(dateStr) {
  return new Date(dateStr) < new Date(new Date().toDateString());
}

export default function Drivers() {
  const { user } = useAuth();
  const canManage = user?.role === "FleetManager" || user?.role === "SafetyOfficer";
  const [drivers, setDrivers] = useState([]);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);

  async function load() {
    try { setDrivers(await api.get("/drivers")); } catch (err) { setError(err.message); }
  }
  useEffect(() => { load(); }, []);

  function openCreate() { setForm(EMPTY); setModalOpen(true); }

  async function submit(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/drivers", { ...form, safety_score: Number(form.safety_score) });
      setModalOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  async function toggleSuspend(d) {
    try {
      if (d.status === "Suspended") await api.post(`/drivers/${d.id}/reinstate`);
      else await api.post(`/drivers/${d.id}/suspend`);
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Drivers</h2>
          <div className="sub">Profiles, license status, and safety compliance</div>
        </div>
        {canManage && <button className="btn-primary" onClick={openCreate}>+ Add Driver</button>}
      </div>

      {error && <div className="alert-banner">{error}</div>}

      <div className="panel">
        <table>
          <thead>
            <tr>
              <th>Name</th><th>License No.</th><th>Category</th><th>Expiry</th>
              <th>Safety Score</th><th>Status</th>{canManage && <th></th>}
            </tr>
          </thead>
          <tbody>
            {drivers.length === 0 && (
              <tr className="empty-row"><td colSpan={canManage ? 7 : 6}>No drivers found.</td></tr>
            )}
            {drivers.map((d) => (
              <tr key={d.id}>
                <td style={{ fontFamily: "var(--font-body)" }}>{d.name}</td>
                <td>{d.license_number}</td>
                <td>{d.license_category}</td>
                <td style={{ color: isExpired(d.license_expiry) ? "var(--danger)" : "inherit" }}>
                  {d.license_expiry}{isExpired(d.license_expiry) ? " (expired)" : ""}
                </td>
                <td>{d.safety_score}</td>
                <td><StatusBadge status={d.status} /></td>
                {canManage && (
                  <td style={{ fontFamily: "var(--font-body)" }}>
                    {d.status !== "On Trip" && (
                      <button className="btn-ghost" style={{ color: d.status === "Suspended" ? "var(--success)" : "var(--danger)" }} onClick={() => toggleSuspend(d)}>
                        {d.status === "Suspended" ? "Reinstate" : "Suspend"}
                      </button>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modalOpen && (
        <div className="modal-backdrop" onClick={() => setModalOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Add Driver</h3>
            <form onSubmit={submit}>
              <div className="field">
                <label>Full Name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="form-row">
                <div className="field">
                  <label>License Number</label>
                  <input required value={form.license_number} onChange={(e) => setForm({ ...form, license_number: e.target.value })} />
                </div>
                <div className="field">
                  <label>Category</label>
                  <select value={form.license_category} onChange={(e) => setForm({ ...form, license_category: e.target.value })}>
                    <option value="LMV">LMV</option>
                    <option value="HMV">HMV</option>
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="field">
                  <label>License Expiry</label>
                  <input required type="date" value={form.license_expiry} onChange={(e) => setForm({ ...form, license_expiry: e.target.value })} />
                </div>
                <div className="field">
                  <label>Contact Number</label>
                  <input value={form.contact_number} onChange={(e) => setForm({ ...form, contact_number: e.target.value })} />
                </div>
              </div>
              <div className="field">
                <label>Safety Score (0–100)</label>
                <input type="number" min="0" max="100" value={form.safety_score} onChange={(e) => setForm({ ...form, safety_score: e.target.value })} />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setModalOpen(false)}>Cancel</button>
                <button type="submit" className="btn-primary">Add Driver</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
