import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";
import StatusBadge from "../components/StatusBadge";

const EMPTY = { registration_number: "", name: "", type: "Van", max_load_capacity: "", odometer: "", acquisition_cost: "", region: "" };

export default function Vehicles() {
  const { user } = useAuth();
  const canManage = user?.role === "FleetManager";
  const [vehicles, setVehicles] = useState([]);
  const [statusFilter, setStatusFilter] = useState("");
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);

  async function load() {
    try {
      const params = statusFilter ? `?status=${encodeURIComponent(statusFilter)}` : "";
      setVehicles(await api.get(`/vehicles${params}`));
    } catch (err) { setError(err.message); }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [statusFilter]);

  function openCreate() {
    setEditing(null);
    setForm(EMPTY);
    setModalOpen(true);
  }

  function openEdit(v) {
    setEditing(v);
    setForm({ ...v });
    setModalOpen(true);
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    try {
      const payload = {
        ...form,
        max_load_capacity: Number(form.max_load_capacity),
        odometer: Number(form.odometer) || 0,
        acquisition_cost: Number(form.acquisition_cost)
      };
      if (editing) await api.put(`/vehicles/${editing.id}`, payload);
      else await api.post("/vehicles", payload);
      setModalOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  async function retire(v) {
    if (!confirm(`Retire vehicle ${v.registration_number}? It will no longer be dispatchable.`)) return;
    try {
      await api.post(`/vehicles/${v.id}/retire`);
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Vehicle Registry</h2>
          <div className="sub">Master list of fleet vehicles and their live status</div>
        </div>
        {canManage && <button className="btn-primary" onClick={openCreate}>+ Register Vehicle</button>}
      </div>

      {error && <div className="alert-banner">{error}</div>}

      <div className="toolbar">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All Statuses</option>
          <option value="Available">Available</option>
          <option value="On Trip">On Trip</option>
          <option value="In Shop">In Shop</option>
          <option value="Retired">Retired</option>
        </select>
      </div>

      <div className="panel">
        <table>
          <thead>
            <tr>
              <th>Reg. No.</th><th>Name</th><th>Type</th><th>Max Load</th>
              <th>Odometer</th><th>Region</th><th>Status</th>{canManage && <th></th>}
            </tr>
          </thead>
          <tbody>
            {vehicles.length === 0 && (
              <tr className="empty-row"><td colSpan={canManage ? 8 : 7}>No vehicles found.</td></tr>
            )}
            {vehicles.map((v) => (
              <tr key={v.id}>
                <td>{v.registration_number}</td>
                <td style={{ fontFamily: "var(--font-body)" }}>{v.name}</td>
                <td>{v.type}</td>
                <td>{v.max_load_capacity} kg</td>
                <td>{v.odometer.toLocaleString()} km</td>
                <td>{v.region}</td>
                <td><StatusBadge status={v.status} /></td>
                {canManage && (
                  <td style={{ fontFamily: "var(--font-body)" }}>
                    <button className="btn-ghost" onClick={() => openEdit(v)}>Edit</button>
                    {v.status !== "Retired" && (
                      <button className="btn-ghost" style={{ color: "var(--danger)" }} onClick={() => retire(v)}>Retire</button>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modalOpen && (
        <div className="modal-backdrop" onClick={() => setModalOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>{editing ? "Edit Vehicle" : "Register Vehicle"}</h3>
            <form onSubmit={submit}>
              <div className="field">
                <label>Registration Number</label>
                <input required value={form.registration_number} onChange={(e) => setForm({ ...form, registration_number: e.target.value })} />
              </div>
              <div className="field">
                <label>Name / Model</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="form-row">
                <div className="field">
                  <label>Type</label>
                  <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                    <option value="Van">Van</option>
                    <option value="Truck">Truck</option>
                  </select>
                </div>
                <div className="field">
                  <label>Max Load Capacity (kg)</label>
                  <input required type="number" value={form.max_load_capacity} onChange={(e) => setForm({ ...form, max_load_capacity: e.target.value })} />
                </div>
              </div>
              <div className="form-row">
                <div className="field">
                  <label>Odometer (km)</label>
                  <input type="number" value={form.odometer} onChange={(e) => setForm({ ...form, odometer: e.target.value })} />
                </div>
                <div className="field">
                  <label>Acquisition Cost (₹)</label>
                  <input required type="number" value={form.acquisition_cost} onChange={(e) => setForm({ ...form, acquisition_cost: e.target.value })} />
                </div>
              </div>
              <div className="field">
                <label>Region</label>
                <input value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} placeholder="e.g. South" />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setModalOpen(false)}>Cancel</button>
                <button type="submit" className="btn-primary">{editing ? "Save Changes" : "Register"}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
