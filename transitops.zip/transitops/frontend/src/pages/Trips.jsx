import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";
import StatusBadge from "../components/StatusBadge";
import CapacityGauge from "../components/CapacityGauge";

const EMPTY = { source: "", destination: "", vehicle_id: "", driver_id: "", cargo_weight: "", planned_distance: "" };

export default function Trips() {
  const { user } = useAuth();
  const canManage = user?.role === "FleetManager" || user?.role === "Driver";
  const [trips, setTrips] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [statusFilter, setStatusFilter] = useState("");
  const [error, setError] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [completeTarget, setCompleteTarget] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [completeForm, setCompleteForm] = useState({ final_odometer: "", fuel_consumed: "", fuel_cost: "", revenue: "" });

  async function load() {
    try {
      const params = statusFilter ? `?status=${encodeURIComponent(statusFilter)}` : "";
      setTrips(await api.get(`/trips${params}`));
    } catch (err) { setError(err.message); }
  }

  async function loadDispatchPool() {
    setVehicles(await api.get("/vehicles?dispatchable=true"));
    setDrivers(await api.get("/drivers?dispatchable=true"));
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [statusFilter]);

  function openCreate() {
    setForm(EMPTY);
    setError("");
    loadDispatchPool();
    setCreateOpen(true);
  }

  const selectedVehicle = vehicles.find((v) => String(v.id) === String(form.vehicle_id));

  async function submitCreate(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/trips", {
        ...form,
        vehicle_id: Number(form.vehicle_id),
        driver_id: Number(form.driver_id),
        cargo_weight: Number(form.cargo_weight),
        planned_distance: Number(form.planned_distance)
      });
      setCreateOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  async function dispatch(trip) {
    setError("");
    try { await api.post(`/trips/${trip.id}/dispatch`); load(); }
    catch (err) { setError(err.message); }
  }

  async function cancel(trip) {
    if (!confirm(`Cancel trip #${trip.id}? This will free the vehicle and driver.`)) return;
    setError("");
    try { await api.post(`/trips/${trip.id}/cancel`); load(); }
    catch (err) { setError(err.message); }
  }

  function openComplete(trip) {
    setCompleteTarget(trip);
    setCompleteForm({ final_odometer: "", fuel_consumed: "", fuel_cost: "", revenue: "" });
  }

  async function submitComplete(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post(`/trips/${completeTarget.id}/complete`, {
        final_odometer: completeForm.final_odometer ? Number(completeForm.final_odometer) : null,
        fuel_consumed: Number(completeForm.fuel_consumed) || 0,
        fuel_cost: Number(completeForm.fuel_cost) || 0,
        revenue: Number(completeForm.revenue) || 0
      });
      setCompleteTarget(null);
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Trips</h2>
          <div className="sub">Draft &rarr; Dispatched &rarr; Completed / Cancelled</div>
        </div>
        {canManage && <button className="btn-primary" onClick={openCreate}>+ Create Trip</button>}
      </div>

      {error && <div className="alert-banner">{error}</div>}

      <div className="toolbar">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All Statuses</option>
          <option value="Draft">Draft</option>
          <option value="Dispatched">Dispatched</option>
          <option value="Completed">Completed</option>
          <option value="Cancelled">Cancelled</option>
        </select>
      </div>

      <div className="panel">
        <table>
          <thead>
            <tr>
              <th>#</th><th>Route</th><th>Vehicle</th><th>Driver</th>
              <th>Cargo</th><th>Distance</th><th>Status</th>{canManage && <th></th>}
            </tr>
          </thead>
          <tbody>
            {trips.length === 0 && (
              <tr className="empty-row"><td colSpan={canManage ? 8 : 7}>No trips found.</td></tr>
            )}
            {trips.map((t) => (
              <tr key={t.id}>
                <td>{t.id}</td>
                <td style={{ fontFamily: "var(--font-body)" }}>{t.source} &rarr; {t.destination}</td>
                <td>{t.registration_number}</td>
                <td style={{ fontFamily: "var(--font-body)" }}>{t.driver_name}</td>
                <td>{t.cargo_weight} kg</td>
                <td>{t.actual_distance ?? t.planned_distance} km</td>
                <td><StatusBadge status={t.status} /></td>
                {canManage && (
                  <td style={{ fontFamily: "var(--font-body)" }}>
                    {t.status === "Draft" && <button className="btn-ghost" style={{ color: "var(--cyan)" }} onClick={() => dispatch(t)}>Dispatch</button>}
                    {t.status === "Dispatched" && <button className="btn-ghost" style={{ color: "var(--success)" }} onClick={() => openComplete(t)}>Complete</button>}
                    {(t.status === "Draft" || t.status === "Dispatched") && (
                      <button className="btn-ghost" style={{ color: "var(--danger)" }} onClick={() => cancel(t)}>Cancel</button>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {createOpen && (
        <div className="modal-backdrop" onClick={() => setCreateOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Create Trip</h3>
            <form onSubmit={submitCreate}>
              <div className="form-row">
                <div className="field">
                  <label>Source</label>
                  <input required value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })} />
                </div>
                <div className="field">
                  <label>Destination</label>
                  <input required value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} />
                </div>
              </div>
              <div className="field">
                <label>Vehicle (available only)</label>
                <select required value={form.vehicle_id} onChange={(e) => setForm({ ...form, vehicle_id: e.target.value })}>
                  <option value="">Select vehicle…</option>
                  {vehicles.map((v) => (
                    <option key={v.id} value={v.id}>{v.registration_number} &mdash; {v.name} ({v.max_load_capacity}kg max)</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Driver (available only)</label>
                <select required value={form.driver_id} onChange={(e) => setForm({ ...form, driver_id: e.target.value })}>
                  <option value="">Select driver…</option>
                  {drivers.map((d) => (
                    <option key={d.id} value={d.id}>{d.name} &mdash; expires {d.license_expiry}</option>
                  ))}
                </select>
              </div>
              <div className="form-row">
                <div className="field">
                  <label>Cargo Weight (kg)</label>
                  <input required type="number" value={form.cargo_weight} onChange={(e) => setForm({ ...form, cargo_weight: e.target.value })} />
                </div>
                <div className="field">
                  <label>Planned Distance (km)</label>
                  <input required type="number" value={form.planned_distance} onChange={(e) => setForm({ ...form, planned_distance: e.target.value })} />
                </div>
              </div>

              {selectedVehicle && (
                <CapacityGauge cargoWeight={form.cargo_weight} maxCapacity={selectedVehicle.max_load_capacity} />
              )}

              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setCreateOpen(false)}>Cancel</button>
                <button
                  type="submit"
                  className="btn-primary"
                  disabled={selectedVehicle && Number(form.cargo_weight) > selectedVehicle.max_load_capacity}
                >
                  Create Draft Trip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {completeTarget && (
        <div className="modal-backdrop" onClick={() => setCompleteTarget(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Complete Trip #{completeTarget.id}</h3>
            <form onSubmit={submitComplete}>
              <div className="field">
                <label>Final Odometer Reading (km)</label>
                <input type="number" value={completeForm.final_odometer} onChange={(e) => setCompleteForm({ ...completeForm, final_odometer: e.target.value })} />
              </div>
              <div className="form-row">
                <div className="field">
                  <label>Fuel Consumed (L)</label>
                  <input type="number" value={completeForm.fuel_consumed} onChange={(e) => setCompleteForm({ ...completeForm, fuel_consumed: e.target.value })} />
                </div>
                <div className="field">
                  <label>Fuel Cost (₹)</label>
                  <input type="number" value={completeForm.fuel_cost} onChange={(e) => setCompleteForm({ ...completeForm, fuel_cost: e.target.value })} />
                </div>
              </div>
              <div className="field">
                <label>Trip Revenue (₹)</label>
                <input type="number" value={completeForm.revenue} onChange={(e) => setCompleteForm({ ...completeForm, revenue: e.target.value })} />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setCompleteTarget(null)}>Cancel</button>
                <button type="submit" className="btn-primary">Mark Completed</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
