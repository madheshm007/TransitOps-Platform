import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { api } from "../api";

export default function Reports() {
  const { user } = useAuth();
  const canExport = ["FleetManager", "FinancialAnalyst"].includes(user?.role);
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/reports/vehicles").then(setRows).catch((err) => setError(err.message));
  }, []);

  function exportCsv() {
    const token = localStorage.getItem("transitops_token");
    fetch("/api/reports/vehicles.csv", { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => res.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url; a.download = "vehicle_report.csv"; a.click();
        window.URL.revokeObjectURL(url);
      });
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Reports & Analytics</h2>
          <div className="sub">Fuel efficiency, operational cost, and ROI per vehicle</div>
        </div>
        {canExport && <button className="btn-secondary" onClick={exportCsv}>Export CSV</button>}
      </div>

      {error && <div className="alert-banner">{error}</div>}

      <div className="panel">
        <table>
          <thead>
            <tr>
              <th>Reg. No.</th><th>Distance</th><th>Fuel Used</th><th>Fuel Efficiency</th>
              <th>Fuel Cost</th><th>Maint. Cost</th><th>Op. Cost</th><th>Revenue</th><th>ROI</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr className="empty-row"><td colSpan={9}>No data yet.</td></tr>}
            {rows.map((r) => (
              <tr key={r.vehicle_id}>
                <td>{r.registration_number}</td>
                <td>{r.total_distance_km} km</td>
                <td>{r.total_fuel_liters} L</td>
                <td>{r.fuel_efficiency_km_per_l != null ? `${r.fuel_efficiency_km_per_l} km/L` : "—"}</td>
                <td>₹{r.total_fuel_cost}</td>
                <td>₹{r.total_maintenance_cost}</td>
                <td>₹{r.operational_cost}</td>
                <td>₹{r.revenue}</td>
                <td style={{ color: r.roi_percent != null && r.roi_percent < 0 ? "var(--danger)" : "var(--success)" }}>
                  {r.roi_percent != null ? `${r.roi_percent}%` : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
