import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";

export default function Dashboard() {
  const { user } = useAuth();
  const [kpis, setKpis] = useState(null);
  const [filters, setFilters] = useState({ type: "", status: "", region: "" });
  const [error, setError] = useState("");

  async function load() {
    try {
      const params = new URLSearchParams();
      if (filters.type) params.set("type", filters.type);
      if (filters.status) params.set("status", filters.status);
      if (filters.region) params.set("region", filters.region);
      const data = await api.get(`/dashboard?${params.toString()}`);
      setKpis(data);
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [filters]);

  const cards = kpis && [
    { label: "Active Vehicles", value: kpis.activeVehicles, color: "" },
    { label: "Available Vehicles", value: kpis.availableVehicles, color: "cyan" },
    { label: "In Maintenance", value: kpis.inMaintenance, color: "amber" },
    { label: "Active Trips", value: kpis.activeTrips, color: "cyan" },
    { label: "Pending Trips", value: kpis.pendingTrips, color: "amber" },
    { label: "Drivers On Duty", value: kpis.driversOnDuty, color: "cyan" },
    { label: "Fleet Utilization", value: `${kpis.fleetUtilization}%`, color: "amber" }
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Operations Dashboard</h2>
          <div className="sub">Welcome back, {user?.name} &middot; {user?.role}</div>
        </div>
      </div>

      {error && <div className="alert-banner">{error}</div>}

      <div className="toolbar">
        <select value={filters.type} onChange={(e) => setFilters({ ...filters, type: e.target.value })}>
          <option value="">All Vehicle Types</option>
          <option value="Van">Van</option>
          <option value="Truck">Truck</option>
        </select>
        <select value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })}>
          <option value="">All Statuses</option>
          <option value="Available">Available</option>
          <option value="On Trip">On Trip</option>
          <option value="In Shop">In Shop</option>
          <option value="Retired">Retired</option>
        </select>
        <input
          placeholder="Filter by region…"
          value={filters.region}
          onChange={(e) => setFilters({ ...filters, region: e.target.value })}
        />
      </div>

      {kpis ? (
        <div className="kpi-grid">
          {cards.map((c) => (
            <div className="kpi-card" key={c.label}>
              <div className="label">{c.label}</div>
              <div className={`value ${c.color}`}>{c.value}</div>
            </div>
          ))}
        </div>
      ) : (
        <div className="loading-dim">Loading dashboard…</div>
      )}

      <div className="panel">
        <div className="panel-header"><h3>Getting started</h3></div>
        <div style={{ padding: "16px 18px", color: "var(--text-muted)", fontSize: 13, lineHeight: 1.7 }}>
          Register vehicles and drivers, then create a trip from the Trips tab. Dispatching a trip
          automatically locks the vehicle and driver as "On Trip"; completing or cancelling it frees them again.
          Opening a maintenance record automatically pulls a vehicle out of the dispatch pool.
        </div>
      </div>
    </div>
  );
}
