import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";
import StatusBadge from "../components/StatusBadge";

export default function Maintenance() {
  const { user } = useAuth();
  const canManage = user?.role === "FleetManager";
  const [logs, setLogs] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [error, setError] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [closeTarget, setCloseTarget] = useState(null);
  const [form, setForm] = useState({ vehicle_id: "", description: "", cost: "" });
  const [finalCost, setFinalCost] = useState("");

  async function load() {
    try { setLogs(await api.get("/maintenance")); } catch (err) { setError(err.message); }
  }
  useEffect(() => { load(); }, []);

  async function openCreate() {
    setForm({ vehicle_id: "", description: "", cost: "" });
    setVehicles(await api.get("/vehicles"));
    setCreateOpen(true);
  }

  async function submitCreate(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/maintenance", { ...form, vehicle_id: Number(form.vehicle_id), cost: Number(form.cost) || 0 });
      setCreateOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  function openClose(log) {
    setCloseTarget(log);
    setFinalCost(log.cost);
  }

  async function submitClose(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post(`/maintenance/${closeTarget.id}/close`, { final_cost: Number(finalCost) });
      setCloseTarget(null);
      load();
    } catch (err) { setError(err.message); }
  }

  const eligibleVehicles = vehicles.filter((v) => v.status !== "On Trip" && v.status !== "Retired");

  return (
    <div>
      <div className="page-header">
        <div>
          <h2>Maintenance</h2>
          <div className="sub">Opening a record moves the vehicle to "In Shop" and out of dispatch</div>
        </div>
        {canManage && <button className="btn-primary" onClick={openCreate}>+ New Maintenance Record</button>}
      </div>

      {error && <div className="alert-banner">{error}</div>}

      <div className="panel">
        <table>
          <thead>
            <tr><th>#</th><th>Vehicle</th><th>Description</th><th>Cost</th><th>Status</th>{canManage && <th></th>}</tr>
          </thead>
          <tbody>
            {logs.length === 0 && <tr className="empty-row"><td colSpan={canManage ? 6 : 5}>No maintenance records yet.</td></tr>}
            {logs.map((l) => (
              <tr key={l.id}>
                <td>{l.id}</td>
                <td>{l.registration_number}</td>
                <td style={{ fontFamily: "var(--font-body)" }}>{l.description}</td>
                <td>₹{l.cost}</td>
                <td><StatusBadge status={l.status} /></td>
                {canManage && (
                  <td style={{ fontFamily: "var(--font-body)" }}>
                    {l.status === "Open" && <button className="btn-ghost" style={{ color: "var(--success)" }} onClick={() => openClose(l)}>Close</button>}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {createOpen && (
        <div className="modal-backdrop" onClick={() => setCreateOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>New Maintenance Record</h3>
            <form onSubmit={submitCreate}>
              <div className="field">
                <label>Vehicle</label>
                <select required value={form.vehicle_id} onChange={(e) => setForm({ ...form, vehicle_id: e.target.value })}>
                  <option value="">Select vehicle…</option>
                  {eligibleVehicles.map((v) => (
                    <option key={v.id} value={v.id}>{v.registration_number} &mdash; {v.name} ({v.status})</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Description</label>
                <input required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="e.g. Oil change, brake service" />
              </div>
              <div className="field">
                <label>Estimated Cost (₹)</label>
                <input type="number" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setCreateOpen(false)}>Cancel</button>
                <button type="submit" className="btn-primary">Open Record</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {closeTarget && (
        <div className="modal-backdrop" onClick={() => setCloseTarget(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Close Maintenance #{closeTarget.id}</h3>
            <form onSubmit={submitClose}>
              <div className="field">
                <label>Final Cost (₹)</label>
                <input type="number" value={finalCost} onChange={(e) => setFinalCost(e.target.value)} />
              </div>
              <div className="hint-banner">Closing this record restores the vehicle to Available (unless it has been retired).</div>
              <div className="modal-actions">
                <button type="button" className="btn-secondary" onClick={() => setCloseTarget(null)}>Cancel</button>
                <button type="submit" className="btn-primary">Close Record</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
