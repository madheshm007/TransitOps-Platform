export default function CapacityGauge({ cargoWeight, maxCapacity }) {
  const cargo = Number(cargoWeight) || 0;
  const max = Number(maxCapacity) || 0;
  const pct = max > 0 ? Math.min((cargo / max) * 100, 100) : 0;
  const over = max > 0 && cargo > max;

  let zone = "ok";
  if (over) zone = "over";
  else if (pct >= 80) zone = "warn";

  return (
    <div className="gauge-wrap">
      <div className="gauge-track">
        <div className={`gauge-fill ${zone}`} style={{ width: `${pct}%` }} />
      </div>
      <div className="gauge-label">
        <span>{cargo || 0} kg loaded</span>
        <span>{max || "—"} kg capacity</span>
      </div>
      {over ? (
        <div className="gauge-note over">
          Exceeds max load capacity by {(cargo - max).toLocaleString()} kg &mdash; dispatch will be blocked.
        </div>
      ) : max > 0 ? (
        <div className="gauge-note ok">{pct.toFixed(0)}% of capacity used</div>
      ) : null}
    </div>
  );
}
