const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const initSqlJs = require("sql.js");

const DB_FILE = path.join(__dirname, "transitops.sqlite");

let SQL = null;
let db = null;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('FleetManager','Driver','SafetyOfficer','FinancialAnalyst')),
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS vehicles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  registration_number TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  max_load_capacity REAL NOT NULL,
  odometer REAL DEFAULT 0,
  acquisition_cost REAL NOT NULL,
  region TEXT DEFAULT 'Unassigned',
  status TEXT NOT NULL DEFAULT 'Available' CHECK(status IN ('Available','On Trip','In Shop','Retired')),
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS drivers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  license_number TEXT UNIQUE NOT NULL,
  license_category TEXT NOT NULL,
  license_expiry TEXT NOT NULL,
  contact_number TEXT,
  safety_score REAL DEFAULT 100,
  status TEXT NOT NULL DEFAULT 'Available' CHECK(status IN ('Available','On Trip','Off Duty','Suspended')),
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source TEXT NOT NULL,
  destination TEXT NOT NULL,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  cargo_weight REAL NOT NULL,
  planned_distance REAL NOT NULL,
  actual_distance REAL,
  fuel_consumed REAL,
  revenue REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Draft' CHECK(status IN ('Draft','Dispatched','Completed','Cancelled')),
  created_at TEXT DEFAULT (datetime('now')),
  dispatched_at TEXT,
  completed_at TEXT,
  cancelled_at TEXT
);

CREATE TABLE IF NOT EXISTS maintenance_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
  description TEXT NOT NULL,
  cost REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Open' CHECK(status IN ('Open','Closed')),
  created_at TEXT DEFAULT (datetime('now')),
  closed_at TEXT
);

CREATE TABLE IF NOT EXISTS fuel_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
  trip_id INTEGER REFERENCES trips(id),
  liters REAL NOT NULL,
  cost REAL NOT NULL,
  log_date TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id INTEGER REFERENCES vehicles(id),
  category TEXT NOT NULL,
  amount REAL NOT NULL,
  expense_date TEXT NOT NULL,
  description TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
`;

function save() {
  const data = db.export();
  fs.writeFileSync(DB_FILE, Buffer.from(data));
}

function run(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  stmt.step();
  stmt.free();
  save();
}

function get(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const row = stmt.step() ? stmt.getAsObject() : null;
  stmt.free();
  return row;
}

function all(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function insertAndGetId(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  stmt.step();
  stmt.free();
  const idRow = get("SELECT last_insert_rowid() AS id");
  save();
  return idRow.id;
}

async function init() {
  SQL = await initSqlJs();
  if (fs.existsSync(DB_FILE)) {
    const fileBuffer = fs.readFileSync(DB_FILE);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }
  db.run(SCHEMA);
  save();
  seed();
}

function seed() {
  const userCount = get("SELECT COUNT(*) AS c FROM users").c;
  if (userCount === 0) {
    const users = [
      ["Priya Fleet", "fleetmanager@transitops.com", "Password@123", "FleetManager"],
      ["Alex Driver", "dispatcher@transitops.com", "Password@123", "Driver"],
      ["Sam Safety", "safety@transitops.com", "Password@123", "SafetyOfficer"],
      ["Riya Finance", "finance@transitops.com", "Password@123", "FinancialAnalyst"]
    ];
    users.forEach(([name, email, pw, role]) => {
      const hash = bcrypt.hashSync(pw, 10);
      run("INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)", [name, email, hash, role]);
    });
  }

  const vehicleCount = get("SELECT COUNT(*) AS c FROM vehicles").c;
  if (vehicleCount === 0) {
    const vehicles = [
      ["VAN-05", "Tata Ace Van-05", "Van", 500, 12000, 850000, "South"],
      ["TRK-11", "Ashok Leyland Truck-11", "Truck", 3000, 45000, 2800000, "North"],
      ["VAN-09", "Mahindra Van-09", "Van", 650, 30500, 900000, "South"],
      ["TRK-04", "Eicher Truck-04", "Truck", 5000, 8000, 3200000, "West"]
    ];
    vehicles.forEach(([reg, name, type, cap, odo, cost, region]) => {
      run(
        "INSERT INTO vehicles (registration_number, name, type, max_load_capacity, odometer, acquisition_cost, region, status) VALUES (?,?,?,?,?,?,?, 'Available')",
        [reg, name, type, cap, odo, cost, region]
      );
    });
  }

  const driverCount = get("SELECT COUNT(*) AS c FROM drivers").c;
  if (driverCount === 0) {
    const drivers = [
      ["Alex Kumar", "TN-DL-2201", "LMV", "2027-05-01", "9840011122", 96],
      ["Bala Singh", "TN-DL-2305", "HMV", "2026-08-15", "9840022233", 91],
      ["Chitra Rao", "TN-DL-2110", "LMV", "2025-01-10", "9840033344", 88],
      ["Deepak Nair", "TN-DL-2450", "HMV", "2028-02-20", "9840044455", 99]
    ];
    drivers.forEach(([name, lic, cat, exp, contact, score]) => {
      run(
        "INSERT INTO drivers (name, license_number, license_category, license_expiry, contact_number, safety_score, status) VALUES (?,?,?,?,?,?, 'Available')",
        [name, lic, cat, exp, contact, score]
      );
    });
  }
}

module.exports = { init, run, get, all, insertAndGetId, save };
