require("dotenv").config();
const express = require("express");
const cors = require("cors");
const db = require("./db");

const authRoutes = require("./routes/auth");
const vehicleRoutes = require("./routes/vehicles");
const driverRoutes = require("./routes/drivers");
const tripRoutes = require("./routes/trips");
const maintenanceRoutes = require("./routes/maintenance");
const fuelRoutes = require("./routes/fuel");
const expenseRoutes = require("./routes/expenses");
const dashboardRoutes = require("./routes/dashboard");
const reportRoutes = require("./routes/reports");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/vehicles", vehicleRoutes);
app.use("/api/drivers", driverRoutes);
app.use("/api/trips", tripRoutes);
app.use("/api/maintenance", maintenanceRoutes);
app.use("/api/fuel-logs", fuelRoutes);
app.use("/api/expenses", expenseRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/reports", reportRoutes);

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

db.init().then(() => {
  app.listen(PORT, () => {
    console.log(`TransitOps API running on http://localhost:${PORT}`);
    console.log(`Seeded demo logins (password: Password@123):`);
    console.log(`  fleetmanager@transitops.com  (FleetManager)`);
    console.log(`  dispatcher@transitops.com    (Driver)`);
    console.log(`  safety@transitops.com        (SafetyOfficer)`);
    console.log(`  finance@transitops.com       (FinancialAnalyst)`);
  });
}).catch(err => {
  console.error("Failed to initialize database:", err);
  process.exit(1);
});
