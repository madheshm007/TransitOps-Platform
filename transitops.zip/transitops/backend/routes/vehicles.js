const express = require("express");
const db = require("../db");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

// GET /api/vehicles?status=&type=&region=&dispatchable=true
router.get("/", (req, res) => {
  const { status, type, region, dispatchable } = req.query;
  let sql = "SELECT * FROM vehicles WHERE 1=1";
  const params = [];
  if (status) { sql += " AND status = ?"; params.push(status); }
  if (type) { sql += " AND type = ?"; params.push(type); }
  if (region) { sql += " AND region = ?"; params.push(region); }
  if (dispatchable === "true") { sql += " AND status = 'Available'"; }
  sql += " ORDER BY id DESC";
  res.json(db.all(sql, params));
});

router.get("/:id", (req, res) => {
  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [req.params.id]);
  if (!vehicle) return res.status(404).json({ error: "Vehicle not found." });
  res.json(vehicle);
});

router.post("/", authorize("FleetManager"), (req, res) => {
  const { registration_number, name, type, max_load_capacity, odometer, acquisition_cost, region } = req.body;
  if (!registration_number || !name || !type || !max_load_capacity || !acquisition_cost) {
    return res.status(400).json({ error: "Missing required vehicle fields." });
  }
  const existing = db.get("SELECT id FROM vehicles WHERE registration_number = ?", [registration_number]);
  if (existing) return res.status(409).json({ error: "Registration number must be unique." });

  const id = db.insertAndGetId(
    "INSERT INTO vehicles (registration_number, name, type, max_load_capacity, odometer, acquisition_cost, region, status) VALUES (?,?,?,?,?,?,?, 'Available')",
    [registration_number, name, type, max_load_capacity, odometer || 0, acquisition_cost, region || "Unassigned"]
  );
  res.status(201).json(db.get("SELECT * FROM vehicles WHERE id = ?", [id]));
});

router.put("/:id", authorize("FleetManager"), (req, res) => {
  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [req.params.id]);
  if (!vehicle) return res.status(404).json({ error: "Vehicle not found." });

  const { name, type, max_load_capacity, odometer, acquisition_cost, region, registration_number } = req.body;

  if (registration_number && registration_number !== vehicle.registration_number) {
    const dupe = db.get("SELECT id FROM vehicles WHERE registration_number = ? AND id != ?", [registration_number, vehicle.id]);
    if (dupe) return res.status(409).json({ error: "Registration number must be unique." });
  }

  db.run(
    `UPDATE vehicles SET
      registration_number = COALESCE(?, registration_number),
      name = COALESCE(?, name),
      type = COALESCE(?, type),
      max_load_capacity = COALESCE(?, max_load_capacity),
      odometer = COALESCE(?, odometer),
      acquisition_cost = COALESCE(?, acquisition_cost),
      region = COALESCE(?, region)
     WHERE id = ?`,
    [registration_number, name, type, max_load_capacity, odometer, acquisition_cost, region, vehicle.id]
  );
  res.json(db.get("SELECT * FROM vehicles WHERE id = ?", [vehicle.id]));
});

// Retire a vehicle (business rule: retired vehicles never appear in dispatch)
router.post("/:id/retire", authorize("FleetManager"), (req, res) => {
  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [req.params.id]);
  if (!vehicle) return res.status(404).json({ error: "Vehicle not found." });
  if (vehicle.status === "On Trip") return res.status(409).json({ error: "Cannot retire a vehicle that is currently on a trip." });
  db.run("UPDATE vehicles SET status = 'Retired' WHERE id = ?", [vehicle.id]);
  res.json(db.get("SELECT * FROM vehicles WHERE id = ?", [vehicle.id]));
});

router.delete("/:id", authorize("FleetManager"), (req, res) => {
  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [req.params.id]);
  if (!vehicle) return res.status(404).json({ error: "Vehicle not found." });
  if (vehicle.status === "On Trip") return res.status(409).json({ error: "Cannot delete a vehicle that is currently on a trip." });
  db.run("DELETE FROM vehicles WHERE id = ?", [vehicle.id]);
  res.status(204).end();
});

module.exports = router;
