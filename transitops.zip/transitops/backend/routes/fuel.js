const express = require("express");
const db = require("../db");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

router.get("/", (req, res) => {
  const { vehicle_id } = req.query;
  let sql = `SELECT f.*, v.registration_number FROM fuel_logs f JOIN vehicles v ON v.id = f.vehicle_id WHERE 1=1`;
  const params = [];
  if (vehicle_id) { sql += " AND f.vehicle_id = ?"; params.push(vehicle_id); }
  sql += " ORDER BY f.id DESC";
  res.json(db.all(sql, params));
});

router.post("/", authorize("FleetManager", "FinancialAnalyst", "Driver"), (req, res) => {
  const { vehicle_id, liters, cost, log_date, trip_id } = req.body;
  if (!vehicle_id || !liters || !cost || !log_date) {
    return res.status(400).json({ error: "vehicle_id, liters, cost and log_date are required." });
  }
  const id = db.insertAndGetId(
    "INSERT INTO fuel_logs (vehicle_id, trip_id, liters, cost, log_date) VALUES (?,?,?,?,?)",
    [vehicle_id, trip_id || null, liters, cost, log_date]
  );
  res.status(201).json(db.get("SELECT * FROM fuel_logs WHERE id = ?", [id]));
});

module.exports = router;
