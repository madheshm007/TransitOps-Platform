const express = require("express");
const db = require("../db");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

function buildVehicleReport() {
  const vehicles = db.all("SELECT * FROM vehicles");
  return vehicles.map(v => {
    const fuelTotals = db.get(
      "SELECT COALESCE(SUM(liters),0) AS liters, COALESCE(SUM(cost),0) AS cost FROM fuel_logs WHERE vehicle_id = ?",
      [v.id]
    );
    const maintenanceCost = db.get(
      "SELECT COALESCE(SUM(cost),0) AS cost FROM maintenance_logs WHERE vehicle_id = ?",
      [v.id]
    ).cost;
    const distance = db.get(
      "SELECT COALESCE(SUM(actual_distance),0) AS d FROM trips WHERE vehicle_id = ? AND status = 'Completed'",
      [v.id]
    ).d;
    const revenue = db.get(
      "SELECT COALESCE(SUM(revenue),0) AS r FROM trips WHERE vehicle_id = ? AND status = 'Completed'",
      [v.id]
    ).r;

    const fuelEfficiency = fuelTotals.liters > 0 ? Number((distance / fuelTotals.liters).toFixed(2)) : null;
    const operationalCost = Number((fuelTotals.cost + maintenanceCost).toFixed(2));
    const roi = v.acquisition_cost > 0
      ? Number((((revenue - operationalCost) / v.acquisition_cost) * 100).toFixed(2))
      : null;

    return {
      vehicle_id: v.id,
      registration_number: v.registration_number,
      name: v.name,
      status: v.status,
      total_distance_km: distance,
      total_fuel_liters: fuelTotals.liters,
      fuel_efficiency_km_per_l: fuelEfficiency,
      total_fuel_cost: fuelTotals.cost,
      total_maintenance_cost: maintenanceCost,
      operational_cost: operationalCost,
      revenue,
      roi_percent: roi
    };
  });
}

router.get("/vehicles", (req, res) => {
  res.json(buildVehicleReport());
});

router.get("/vehicles.csv", authorize("FleetManager", "FinancialAnalyst"), (req, res) => {
  const rows = buildVehicleReport();
  const headers = Object.keys(rows[0] || {
    vehicle_id: "", registration_number: "", name: "", status: "",
    total_distance_km: "", total_fuel_liters: "", fuel_efficiency_km_per_l: "",
    total_fuel_cost: "", total_maintenance_cost: "", operational_cost: "", revenue: "", roi_percent: ""
  });
  const csvLines = [headers.join(",")];
  rows.forEach(r => {
    csvLines.push(headers.map(h => JSON.stringify(r[h] ?? "")).join(","));
  });
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=vehicle_report.csv");
  res.send(csvLines.join("\n"));
});

module.exports = router;
