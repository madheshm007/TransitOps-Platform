const express = require("express");
const db = require("../db");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

router.get("/", (req, res) => {
  const { status, dispatchable } = req.query;
  let sql = "SELECT * FROM drivers WHERE 1=1";
  const params = [];
  if (status) { sql += " AND status = ?"; params.push(status); }
  if (dispatchable === "true") {
    sql += " AND status = 'Available' AND license_expiry >= date('now')";
  }
  sql += " ORDER BY id DESC";
  res.json(db.all(sql, params));
});

router.get("/:id", (req, res) => {
  const driver = db.get("SELECT * FROM drivers WHERE id = ?", [req.params.id]);
  if (!driver) return res.status(404).json({ error: "Driver not found." });
  res.json(driver);
});

router.post("/", authorize("FleetManager", "SafetyOfficer"), (req, res) => {
  const { name, license_number, license_category, license_expiry, contact_number, safety_score } = req.body;
  if (!name || !license_number || !license_category || !license_expiry) {
    return res.status(400).json({ error: "Missing required driver fields." });
  }
  const existing = db.get("SELECT id FROM drivers WHERE license_number = ?", [license_number]);
  if (existing) return res.status(409).json({ error: "License number must be unique." });

  const id = db.insertAndGetId(
    "INSERT INTO drivers (name, license_number, license_category, license_expiry, contact_number, safety_score, status) VALUES (?,?,?,?,?,?, 'Available')",
    [name, license_number, license_category, license_expiry, contact_number || null, safety_score ?? 100]
  );
  res.status(201).json(db.get("SELECT * FROM drivers WHERE id = ?", [id]));
});

router.put("/:id", authorize("FleetManager", "SafetyOfficer"), (req, res) => {
  const driver = db.get("SELECT * FROM drivers WHERE id = ?", [req.params.id]);
  if (!driver) return res.status(404).json({ error: "Driver not found." });

  const { name, license_category, license_expiry, contact_number, safety_score, status } = req.body;

  if (status && driver.status === "On Trip" && status !== "On Trip") {
    return res.status(409).json({ error: "Cannot manually change status of a driver currently on a trip." });
  }

  db.run(
    `UPDATE drivers SET
      name = COALESCE(?, name),
      license_category = COALESCE(?, license_category),
      license_expiry = COALESCE(?, license_expiry),
      contact_number = COALESCE(?, contact_number),
      safety_score = COALESCE(?, safety_score),
      status = COALESCE(?, status)
     WHERE id = ?`,
    [name, license_category, license_expiry, contact_number, safety_score, status, driver.id]
  );
  res.json(db.get("SELECT * FROM drivers WHERE id = ?", [driver.id]));
});

// Suspend a driver (Safety Officer compliance action)
router.post("/:id/suspend", authorize("SafetyOfficer", "FleetManager"), (req, res) => {
  const driver = db.get("SELECT * FROM drivers WHERE id = ?", [req.params.id]);
  if (!driver) return res.status(404).json({ error: "Driver not found." });
  if (driver.status === "On Trip") return res.status(409).json({ error: "Cannot suspend a driver currently on a trip." });
  db.run("UPDATE drivers SET status = 'Suspended' WHERE id = ?", [driver.id]);
  res.json(db.get("SELECT * FROM drivers WHERE id = ?", [driver.id]));
});

router.post("/:id/reinstate", authorize("SafetyOfficer", "FleetManager"), (req, res) => {
  const driver = db.get("SELECT * FROM drivers WHERE id = ?", [req.params.id]);
  if (!driver) return res.status(404).json({ error: "Driver not found." });
  db.run("UPDATE drivers SET status = 'Available' WHERE id = ?", [driver.id]);
  res.json(db.get("SELECT * FROM drivers WHERE id = ?", [driver.id]));
});

module.exports = router;
