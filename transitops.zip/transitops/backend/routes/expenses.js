const express = require("express");
const db = require("../db");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

router.get("/", (req, res) => {
  const { vehicle_id } = req.query;
  let sql = "SELECT * FROM expenses WHERE 1=1";
  const params = [];
  if (vehicle_id) { sql += " AND vehicle_id = ?"; params.push(vehicle_id); }
  sql += " ORDER BY id DESC";
  res.json(db.all(sql, params));
});

router.post("/", authorize("FleetManager", "FinancialAnalyst"), (req, res) => {
  const { vehicle_id, category, amount, expense_date, description } = req.body;
  if (!category || !amount || !expense_date) {
    return res.status(400).json({ error: "category, amount and expense_date are required." });
  }
  const id = db.insertAndGetId(
    "INSERT INTO expenses (vehicle_id, category, amount, expense_date, description) VALUES (?,?,?,?,?)",
    [vehicle_id || null, category, amount, expense_date, description || null]
  );
  res.status(201).json(db.get("SELECT * FROM expenses WHERE id = ?", [id]));
});

module.exports = router;
