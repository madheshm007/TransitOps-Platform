const express = require("express");
const db = require("../db");
const { authenticate } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

router.get("/", (req, res) => {
  const { type, status, region } = req.query;

  let vSql = "SELECT * FROM vehicles WHERE 1=1";
  const vParams = [];
  if (type) { vSql += " AND type = ?"; vParams.push(type); }
  if (status) { vSql += " AND status = ?"; vParams.push(status); }
  if (region) { vSql += " AND region = ?"; vParams.push(region); }
  const vehicles = db.all(vSql, vParams);

  const activeVehicles = vehicles.filter(v => v.status !== "Retired").length;
  const availableVehicles = vehicles.filter(v => v.status === "Available").length;
  const inMaintenance = vehicles.filter(v => v.status === "In Shop").length;
  const onTripVehicles = vehicles.filter(v => v.status === "On Trip").length;

  const activeTrips = db.get("SELECT COUNT(*) AS c FROM trips WHERE status = 'Dispatched'").c;
  const pendingTrips = db.get("SELECT COUNT(*) AS c FROM trips WHERE status = 'Draft'").c;
  const driversOnDuty = db.get("SELECT COUNT(*) AS c FROM drivers WHERE status = 'On Trip'").c;

  const utilization = activeVehicles > 0 ? Number(((onTripVehicles / activeVehicles) * 100).toFixed(1)) : 0;

  res.json({
    activeVehicles,
    availableVehicles,
    inMaintenance,
    activeTrips,
    pendingTrips,
    driversOnDuty,
    fleetUtilization: utilization
  });
});

module.exports = router;
