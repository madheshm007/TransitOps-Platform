const express = require("express");
const db = require("../db");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

router.get("/", (req, res) => {
  const { status } = req.query;
  let sql = `
    SELECT t.*, v.registration_number, v.name AS vehicle_name, d.name AS driver_name
    FROM trips t
    JOIN vehicles v ON v.id = t.vehicle_id
    JOIN drivers d ON d.id = t.driver_id
    WHERE 1=1`;
  const params = [];
  if (status) { sql += " AND t.status = ?"; params.push(status); }
  sql += " ORDER BY t.id DESC";
  res.json(db.all(sql, params));
});

router.get("/:id", (req, res) => {
  const trip = db.get("SELECT * FROM trips WHERE id = ?", [req.params.id]);
  if (!trip) return res.status(404).json({ error: "Trip not found." });
  res.json(trip);
});

// Create a Draft trip (does not touch vehicle/driver status yet)
router.post("/", authorize("FleetManager", "Driver"), (req, res) => {
  const { source, destination, vehicle_id, driver_id, cargo_weight, planned_distance } = req.body;
  if (!source || !destination || !vehicle_id || !driver_id || !cargo_weight || !planned_distance) {
    return res.status(400).json({ error: "Missing required trip fields." });
  }

  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [vehicle_id]);
  const driver = db.get("SELECT * FROM drivers WHERE id = ?", [driver_id]);
  if (!vehicle) return res.status(404).json({ error: "Vehicle not found." });
  if (!driver) return res.status(404).json({ error: "Driver not found." });

  if (cargo_weight > vehicle.max_load_capacity) {
    return res.status(422).json({
      error: `Cargo weight (${cargo_weight}kg) exceeds vehicle max load capacity (${vehicle.max_load_capacity}kg).`
    });
  }

  const id = db.insertAndGetId(
    "INSERT INTO trips (source, destination, vehicle_id, driver_id, cargo_weight, planned_distance, status) VALUES (?,?,?,?,?,?, 'Draft')",
    [source, destination, vehicle_id, driver_id, cargo_weight, planned_distance]
  );
  res.status(201).json(db.get("SELECT * FROM trips WHERE id = ?", [id]));
});

// Dispatch: Draft -> Dispatched. Validates and locks vehicle+driver.
router.post("/:id/dispatch", authorize("FleetManager", "Driver"), (req, res) => {
  const trip = db.get("SELECT * FROM trips WHERE id = ?", [req.params.id]);
  if (!trip) return res.status(404).json({ error: "Trip not found." });
  if (trip.status !== "Draft") return res.status(409).json({ error: `Only Draft trips can be dispatched (current status: ${trip.status}).` });

  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [trip.vehicle_id]);
  const driver = db.get("SELECT * FROM drivers WHERE id = ?", [trip.driver_id]);

  if (vehicle.status === "Retired" || vehicle.status === "In Shop") {
    return res.status(409).json({ error: `Vehicle ${vehicle.registration_number} is ${vehicle.status} and cannot be dispatched.` });
  }
  if (vehicle.status === "On Trip") {
    return res.status(409).json({ error: `Vehicle ${vehicle.registration_number} is already on another trip.` });
  }
  if (driver.status === "Suspended") {
    return res.status(409).json({ error: `Driver ${driver.name} is suspended and cannot be assigned.` });
  }
  if (driver.status === "On Trip") {
    return res.status(409).json({ error: `Driver ${driver.name} is already on another trip.` });
  }
  const today = new Date().toISOString().slice(0, 10);
  if (driver.license_expiry < today) {
    return res.status(409).json({ error: `Driver ${driver.name}'s license expired on ${driver.license_expiry}.` });
  }
  if (trip.cargo_weight > vehicle.max_load_capacity) {
    return res.status(422).json({ error: `Cargo weight (${trip.cargo_weight}kg) exceeds vehicle max load capacity (${vehicle.max_load_capacity}kg).` });
  }

  db.run("UPDATE vehicles SET status = 'On Trip' WHERE id = ?", [vehicle.id]);
  db.run("UPDATE drivers SET status = 'On Trip' WHERE id = ?", [driver.id]);
  db.run("UPDATE trips SET status = 'Dispatched', dispatched_at = datetime('now') WHERE id = ?", [trip.id]);

  res.json(db.get("SELECT * FROM trips WHERE id = ?", [trip.id]));
});

// Complete: Dispatched -> Completed. Records odometer/fuel/revenue, frees vehicle+driver.
router.post("/:id/complete", authorize("FleetManager", "Driver"), (req, res) => {
  const trip = db.get("SELECT * FROM trips WHERE id = ?", [req.params.id]);
  if (!trip) return res.status(404).json({ error: "Trip not found." });
  if (trip.status !== "Dispatched") return res.status(409).json({ error: `Only Dispatched trips can be completed (current status: ${trip.status}).` });

  const { final_odometer, fuel_consumed, revenue } = req.body;
  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [trip.vehicle_id]);

  const actualDistance = final_odometer != null ? Math.max(0, final_odometer - vehicle.odometer) : trip.planned_distance;

  db.run(
    "UPDATE trips SET status = 'Completed', actual_distance = ?, fuel_consumed = ?, revenue = ?, completed_at = datetime('now') WHERE id = ?",
    [actualDistance, fuel_consumed || 0, revenue || 0, trip.id]
  );

  if (final_odometer != null) {
    db.run("UPDATE vehicles SET odometer = ? WHERE id = ?", [final_odometer, vehicle.id]);
  }
  db.run("UPDATE vehicles SET status = 'Available' WHERE id = ?", [trip.vehicle_id]);
  db.run("UPDATE drivers SET status = 'Available' WHERE id = ?", [trip.driver_id]);

  if (fuel_consumed) {
    db.run(
      "INSERT INTO fuel_logs (vehicle_id, trip_id, liters, cost, log_date) VALUES (?,?,?,?, date('now'))",
      [trip.vehicle_id, trip.id, fuel_consumed, req.body.fuel_cost || 0]
    );
  }

  res.json(db.get("SELECT * FROM trips WHERE id = ?", [trip.id]));
});

// Cancel: Draft or Dispatched -> Cancelled. Restores vehicle+driver if they were locked.
router.post("/:id/cancel", authorize("FleetManager", "Driver"), (req, res) => {
  const trip = db.get("SELECT * FROM trips WHERE id = ?", [req.params.id]);
  if (!trip) return res.status(404).json({ error: "Trip not found." });
  if (!["Draft", "Dispatched"].includes(trip.status)) {
    return res.status(409).json({ error: `Trip in status ${trip.status} cannot be cancelled.` });
  }

  if (trip.status === "Dispatched") {
    db.run("UPDATE vehicles SET status = 'Available' WHERE id = ?", [trip.vehicle_id]);
    db.run("UPDATE drivers SET status = 'Available' WHERE id = ?", [trip.driver_id]);
  }
  db.run("UPDATE trips SET status = 'Cancelled', cancelled_at = datetime('now') WHERE id = ?", [trip.id]);
  res.json(db.get("SELECT * FROM trips WHERE id = ?", [trip.id]));
});

module.exports = router;
