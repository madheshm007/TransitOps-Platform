const express = require("express");
const db = require("../db");
const { authenticate, authorize } = require("../middleware/auth");

const router = express.Router();
router.use(authenticate);

router.get("/", (req, res) => {
  const sql = `
    SELECT m.*, v.registration_number, v.name AS vehicle_name
    FROM maintenance_logs m JOIN vehicles v ON v.id = m.vehicle_id
    ORDER BY m.id DESC`;
  res.json(db.all(sql));
});

// Opening a maintenance record automatically flips vehicle to 'In Shop'
router.post("/", authorize("FleetManager"), (req, res) => {
  const { vehicle_id, description, cost } = req.body;
  if (!vehicle_id || !description) return res.status(400).json({ error: "vehicle_id and description are required." });

  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [vehicle_id]);
  if (!vehicle) return res.status(404).json({ error: "Vehicle not found." });
  if (vehicle.status === "On Trip") {
    return res.status(409).json({ error: `Vehicle ${vehicle.registration_number} is on a trip and cannot enter maintenance.` });
  }

  const id = db.insertAndGetId(
    "INSERT INTO maintenance_logs (vehicle_id, description, cost, status) VALUES (?,?,?, 'Open')",
    [vehicle_id, description, cost || 0]
  );
  db.run("UPDATE vehicles SET status = 'In Shop' WHERE id = ?", [vehicle_id]);
  res.status(201).json(db.get("SELECT * FROM maintenance_logs WHERE id = ?", [id]));
});

// Closing maintenance restores vehicle to Available, unless it has been Retired
router.post("/:id/close", authorize("FleetManager"), (req, res) => {
  const log = db.get("SELECT * FROM maintenance_logs WHERE id = ?", [req.params.id]);
  if (!log) return res.status(404).json({ error: "Maintenance record not found." });
  if (log.status === "Closed") return res.status(409).json({ error: "Maintenance record is already closed." });

  const { final_cost } = req.body;
  db.run("UPDATE maintenance_logs SET status = 'Closed', cost = COALESCE(?, cost), closed_at = datetime('now') WHERE id = ?", [final_cost, log.id]);

  const vehicle = db.get("SELECT * FROM vehicles WHERE id = ?", [log.vehicle_id]);
  const openRemaining = db.get("SELECT COUNT(*) AS c FROM maintenance_logs WHERE vehicle_id = ? AND status = 'Open'", [log.vehicle_id]).c;

  if (vehicle.status !== "Retired" && openRemaining === 0) {
    db.run("UPDATE vehicles SET status = 'Available' WHERE id = ?", [log.vehicle_id]);
  }
  res.json(db.get("SELECT * FROM maintenance_logs WHERE id = ?", [log.id]));
});

module.exports = router;
